
# Vault-X PrivateML.ai (Starter)
Minimal, working starter so you can push to your GitHub repo quickly.

## Quickstart (Local)
1. Create and activate a virtual env (optional).
2. Install deps:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the demo app:
   ```bash
   python tee_enclave.py
   ```
   or open the dashboard:
   ```bash
   streamlit run dashboard_bank.py
   ```

This starter uses a **fake `privatevault.py` lock** and a **stubbed Grok call** so you can run without external keys.
Later, swap the stubs with your real SDK and API call.

## Push to your GitHub repo (HTTPS)
> Replace `YOUR_GITHUB_USERNAME` with your GitHub username and use a Personal Access Token instead of a password.

```bash
git init
git add .
git commit -m "chore: initial PrivateML.ai starter"
git branch -M main
git remote add origin https://github.com/LOLA0786/Vault-X.git
git push -u origin main
```

If the remote already exists, do:
```bash
git add .
git commit -m "feat: add working starter"
git push origin main
```

## Files
- `tee_enclave.py` – demo function `ask_grok_blind()` using the local `privatevault` stub and a fake Grok response.
- `privatevault.py` – **stub** implementation (encrypt + fake ZK proof).
- `dashboard_bank.py` – simple Streamlit demo UI.
- `requirements.txt` – minimal deps.
- `tests_robot.py` – tiny smoke test.
- `.gitignore` – Python and venv ignores.
- `push.sh` – one-click-ish push script (HTTPS).
