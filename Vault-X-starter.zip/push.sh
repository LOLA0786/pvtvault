
#!/usr/bin/env bash
set -euo pipefail

# Usage:
#   bash push.sh
#
# Make sure you ran this inside the repo directory.
# If the remote already exists, the add remote line will fail harmlessly.

git add .
git commit -m "feat: add PrivateML.ai starter bundle" || true
git branch -M main || true
git remote add origin https://github.com/LOLA0786/Vault-X.git || true
git push -u origin main
