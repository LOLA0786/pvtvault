
from tee_enclave import ask_grok_blind

def test_smoke():
    out = ask_grok_blind("hello")
    assert "answer" in out and "proof" in out and "encrypted_request" in out
    print("Smoke test passed ✅")

if __name__ == "__main__":
    test_smoke()
