
# dashboard_bank.py - Minimal demo dashboard
import streamlit as st
from tee_enclave import ask_grok_blind

st.title("Vault-X PrivateML.ai — Demo")
st.caption("Local demo (no external keys). Replace stubs with real SDK later.")

q = st.text_input("Ask the 'blind' engine:", "Should we approve Rinky's loan?")
if st.button("Run demo"):
    res = ask_grok_blind(q)
    st.json(res)
